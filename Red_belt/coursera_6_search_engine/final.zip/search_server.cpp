#include "search_server.h"
#include "iterator_range.h"
#include "profile.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <set>
#include <numeric>

vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  //LogDuration log("Adding time");
  InvertedIndex new_index;

  for (string current_document; getline(document_input, current_document); ) {
    new_index.Add(move(current_document));
  }

  index = move(new_index);
}

void SearchServer::AddQueriesStream (
  istream& query_input, ostream& search_results_output
) {
    //LogDuration log("Search time");
    vector<size_t> docid_count(index.getDocumentCount());
    vector<size_t> doc_index(index.getDocumentCount());
    iota(begin(doc_index), end(doc_index), 0);

  for (string current_query; getline(query_input, current_query);) {

    const auto words = SplitIntoWords(current_query);

    fill(begin(docid_count), end(docid_count), 0);

    //log.start_timer("Calc docid_count");

    for (const auto& word : words) {

      for (const auto& docid : index.Lookup(word)) {
        //log.start_timer ("calc_unique");
        docid_count[docid.first] += docid.second;
        //log.finish_timer("calc_unique");
      }
    }

    //log.finish_timer("Calc docid_count");

    //log.start_timer("Sorting");

    partial_sort(
      begin(doc_index),
      begin(doc_index) + min<size_t>(5, doc_index.size()),
      end(doc_index),
      [&docid_count](size_t lhs, size_t rhs) {
        if (docid_count[lhs] > docid_count[rhs]) return true;
        else if (docid_count[lhs] == docid_count[rhs]) {
            return lhs < rhs;
        } else {
            return false;
        }
        return false;
      }
    );

    //log.finish_timer("Sorting");

    search_results_output << current_query << ':';

    //log.start_timer("Analysis");

    for (auto i : Head(doc_index, 5)) {
      if (docid_count[i] == 0) continue;

      search_results_output << " {"
        << "docid: " << i << ", "
        << "hitcount: " << docid_count[i] << '}';
    }

    //log.finish_timer("Analysis");

    search_results_output << endl;
  }
}

void InvertedIndex::Add(const string document) {
  const size_t docid = doc_id++;
  auto words = SplitIntoWords(move(document));
  map<string, size_t> unique_words;

  for (const auto& word : words) {
    unique_words[word]++;
  }

  for (const auto& word : unique_words) {
    vector<pair<size_t, size_t>>& indexes = index[word.first];
    indexes.push_back(make_pair(docid, word.second));
  }
}

const vector<pair<size_t, size_t>>& InvertedIndex::Lookup(const string& word) const {
  if (auto it =  index.find(word); it != index.end()) {
    return it -> second;
  } else {
    return empty_index;
  }
}
